from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    return (ROOT / path).read_text()

def write(path, data):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(data)

def replace(path, old, new, count=1):
    data = read(path)
    if old not in data:
        raise SystemExit(f"pattern not found in {path}: {old[:120]!r}")
    data2 = data.replace(old, new, count)
    write(path, data2)

# Platform fail-open contract.
replace(
    "internal/platform/platform.go",
    "\tEnsureFirewall(context.Context) error\n\tRemoveFirewall(context.Context) error\n}",
    "\tEnsureFirewall(context.Context) error\n\tRemoveFirewall(context.Context) error\n\tEnterDirectBypass(context.Context) error\n\tLeaveDirectBypass(context.Context) error\n\tDirectBypassActive(context.Context) (bool, error)\n}",
)

write("internal/platform/direct_bypass.go", r'''package platform

import (
    "context"
    "errors"
    "fmt"
    "os"
    "path/filepath"
)

var ErrDirectBypassUnsupported = errors.New("platform-level direct bypass is unsupported")

func bypassMarker(cfgPath string) string {
    return filepath.Join(cfgPath, "direct-bypass.active")
}

func markBypass(path string) error {
    if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
        return err
    }
    return os.WriteFile(path, []byte("active\n"), 0o600)
}

func clearBypass(path string) error {
    if err := os.Remove(path); err != nil && !errors.Is(err, os.ErrNotExist) {
        return err
    }
    return nil
}

func markerActive(path string) (bool, error) {
    _, err := os.Stat(path)
    if err == nil {
        return true, nil
    }
    if errors.Is(err, os.ErrNotExist) {
        return false, nil
    }
    return false, err
}

func (g *generic) EnterDirectBypass(ctx context.Context) error {
    if !g.managed {
        return ErrDirectBypassUnsupported
    }
    if err := g.removeFirewallRules(ctx, g.firewallConfig()); err != nil {
        return err
    }
    return markBypass(bypassMarker(g.cfg.Paths.RunDir))
}

func (g *generic) LeaveDirectBypass(ctx context.Context) error {
    if !g.managed {
        return ErrDirectBypassUnsupported
    }
    if err := g.EnsureFirewall(ctx); err != nil {
        return err
    }
    return clearBypass(bypassMarker(g.cfg.Paths.RunDir))
}

func (g *generic) DirectBypassActive(context.Context) (bool, error) {
    if !g.managed {
        return false, ErrDirectBypassUnsupported
    }
    return markerActive(bypassMarker(g.cfg.Paths.RunDir))
}

func (k *keenetic) EnterDirectBypass(ctx context.Context) error {
    if _, err := k.r.Run(ctx, []string{k.cfg.Platform.Keenetic.XKeenBinary, "-stop"}); err != nil {
        return fmt.Errorf("stop XKeen for direct bypass: %w", err)
    }
    return markBypass(bypassMarker(k.cfg.Paths.RunDir))
}

func (k *keenetic) LeaveDirectBypass(ctx context.Context) error {
    if _, err := k.r.Run(ctx, []string{k.cfg.Platform.Keenetic.XKeenBinary, "-start"}); err != nil {
        return fmt.Errorf("start XKeen after direct bypass: %w", err)
    }
    return clearBypass(bypassMarker(k.cfg.Paths.RunDir))
}

func (k *keenetic) DirectBypassActive(context.Context) (bool, error) {
    return markerActive(bypassMarker(k.cfg.Paths.RunDir))
}
''')

# Persistent state can distinguish Xray direct and platform bypass, and surface inconclusive monitoring.
replace(
    "internal/model/model.go",
    "\tDirectMode          bool                   `json:\"direct_mode\"`\n\tConsecutiveFailures int                    `json:\"consecutive_failures\"`",
    "\tDirectMode          bool                   `json:\"direct_mode\"`\n\tPlatformBypass      bool                   `json:\"platform_bypass\"`\n\tHealthState         string                 `json:\"health_state,omitempty\"`\n\tMonitoringDegraded  bool                   `json:\"monitoring_degraded\"`\n\tConsecutiveFailures int                    `json:\"consecutive_failures\"`",
)
replace(
    "internal/model/model.go",
    "s := State{SchemaVersion: 1, Version: version, UpdatedAt: now, StartedAt: now, ActiveSlot: -1, Measurements: map[string]Measurement{}, Sources: map[string]SourceState{}}",
    "s := State{SchemaVersion: 1, Version: version, UpdatedAt: now, StartedAt: now, ActiveSlot: -1, HealthState: \"initializing\", Measurements: map[string]Measurement{}, Sources: map[string]SourceState{}}",
)

# Probe targets concurrently; a nil proxy means truly direct rather than environment-proxy traffic.
replace(
    "internal/bench/probe.go",
    '''func (p *Prober) CheckMajority(ctx context.Context, proxy *url.URL, targets []config.Target) (int, int, []ProbeResult) {
\tpassed := 0
\trs := []ProbeResult{}
\tfor _, t := range targets {
\t\tr := p.Probe(ctx, proxy, t)
\t\trs = append(rs, r)
\t\tif r.Success {
\t\t\tpassed++
\t\t}
\t}
\treturn passed, len(targets), rs
}''',
    '''func (p *Prober) CheckMajority(ctx context.Context, proxy *url.URL, targets []config.Target) (int, int, []ProbeResult) {
\tresults := make([]ProbeResult, len(targets))
\tvar wg sync.WaitGroup
\tfor i, target := range targets {
\t\ti, target := i, target
\t\twg.Add(1)
\t\tgo func() {
\t\t\tdefer wg.Done()
\t\t\tresults[i] = p.Probe(ctx, proxy, target)
\t\t}()
\t}
\twg.Wait()
\tpassed := 0
\tfor _, result := range results {
\t\tif result.Success {
\t\t\tpassed++
\t\t}
\t}
\treturn passed, len(targets), results
}''',
)
replace(
    "internal/bench/probe.go",
    '"strings"\n\t"time"',
    '"strings"\n\t"sync"\n\t"time"',
)
replace(
    "internal/bench/probe.go",
    '''\tif proxy == nil {
\t\ttr.Proxy = http.ProxyFromEnvironment
\t}''',
    '''\tif proxy == nil {
\t\ttr.Proxy = nil
\t}''',
)

# Speed tests must count wire bytes, not transparently decompressed bytes.
replace(
    "internal/bench/engine.go",
    '''tr := &http.Transport{Proxy: http.ProxyURL(proxy), TLSHandshakeTimeout: 10 * time.Second, MaxIdleConns: 2, MaxIdleConnsPerHost: 1}''',
    '''tr := &http.Transport{Proxy: http.ProxyURL(proxy), DisableCompression: true, TLSHandshakeTimeout: 10 * time.Second, MaxIdleConns: 2, MaxIdleConnsPerHost: 1}''',
)
replace(
    "internal/bench/engine.go",
    '''req.Header.Set("User-Agent", "Kee-Route-Manager/1.0")''',
    '''req.Header.Set("User-Agent", "Kee-Route-Manager/1.0")
\treq.Header.Set("Accept-Encoding", "identity")''',
)

# Balancer selector must never include empty blackhole slots.
replace(
    "internal/xray/config.go",
    '''\tbyIndex := map[int]model.Slot{}
\tfor _, s := range slots {
\t\tbyIndex[s.Index] = s
\t}''',
    '''\tbyIndex := map[int]model.Slot{}
\tselectors := []string{}
\tfor _, s := range slots {
\t\tbyIndex[s.Index] = s
\t\tif s.NodeID != "" {
\t\t\tselectors = append(selectors, s.Tag)
\t\t}
\t}''',
)
replace(
    "internal/xray/config.go",
    '''routing := map[string]any{"routing": map[string]any{"balancers": []any{map[string]any{"tag": cfg.Xray.BalancerTag, "selector": []string{cfg.Xray.SlotTagPrefix}, "strategy": map[string]any{"type": "random"}}}, "rules": rules}}''',
    '''if len(selectors) == 0 {
\t\treturn Managed{}, fmt.Errorf("hot pool has no selectable VPN outbounds")
\t}
\trouting := map[string]any{"routing": map[string]any{"balancers": []any{map[string]any{"tag": cfg.Xray.BalancerTag, "selector": selectors, "strategy": map[string]any{"type": "random"}}}, "rules": rules}}''',
)

# Cache Xray status for the public health endpoint and poll it in the platform loop.
replace(
    "internal/core/manager.go",
    '''\tclientsError    string
\trecoveryNode    string''',
    '''\tclientsError    string
\txrayRunning     bool
\txrayUpdated     time.Time
\txrayError       string
\trecoveryNode    string''',
)
replace(
    "internal/core/manager.go",
    '''func (m *Manager) Start(parent context.Context) {
\tm.ctx, m.cancel = context.WithCancel(parent)''',
    '''func (m *Manager) Start(parent context.Context) {
\tm.ctx, m.cancel = context.WithCancel(parent)
\tm.pollXray()''',
)
replace(
    "internal/core/manager.go",
    '''func (m *Manager) Status(ctx context.Context) Status {
\treturn Status{m.version, m.store.State(), m.ops.Current(), m.platform.Capabilities(), m.platform.Kind(), m.platform.XrayRunning(ctx), time.Now().UTC()}
}''',
    '''func (m *Manager) Status(context.Context) Status {
\tm.mu.RLock()
\trunning := m.xrayRunning
\tm.mu.RUnlock()
\treturn Status{m.version, m.store.State(), m.ops.Current(), m.platform.Capabilities(), m.platform.Kind(), running, time.Now().UTC()}
}''',
)
replace(
    "internal/core/manager.go",
    '''\tmetrics := time.NewTicker(5 * time.Second)
\tclients := time.NewTicker(20 * time.Second)
\tdefer metrics.Stop()
\tdefer clients.Stop()
\tm.pollMetrics()
\tm.pollClients()''',
    '''\tmetrics := time.NewTicker(5 * time.Second)
\tclients := time.NewTicker(20 * time.Second)
\txrayStatus := time.NewTicker(3 * time.Second)
\tdefer metrics.Stop()
\tdefer clients.Stop()
\tdefer xrayStatus.Stop()
\tm.pollMetrics()
\tm.pollClients()
\tm.pollXray()''',
)
replace(
    "internal/core/manager.go",
    '''\t\tcase <-clients.C:
\t\t\tm.pollClients()
\t\t}
\t}
}''',
    '''\t\tcase <-clients.C:
\t\t\tm.pollClients()
\t\tcase <-xrayStatus.C:
\t\t\tm.pollXray()
\t\t}
\t}
}''',
)
replace(
    "internal/core/manager.go",
    '''func (m *Manager) pollClients() {''',
    '''func (m *Manager) pollXray() {
\tctx, cancel := context.WithTimeout(m.ctxOrBackground(), 3*time.Second)
\tdefer cancel()
\trunning := m.platform.XrayRunning(ctx)
\tm.mu.Lock()
\tm.xrayRunning = running
\tm.xrayUpdated = time.Now().UTC()
\tif running {
\t\tm.xrayError = ""
\t} else {
\t\tm.xrayError = "Xray is not running"
\t}
\tm.mu.Unlock()
}

func (m *Manager) pollClients() {''',
)

# A benchmark is observational. It must never downgrade routing to direct.
replace(
    "internal/core/manager.go",
    '''\tselected := m.selectPool(fetched.Nodes, results)

\t_ = h.Update("apply", 0, m.cfg.Pool.Size, "applying hot pool")''',
    '''\tselected := m.selectPool(fetched.Nodes, results)
\tif len(selected) == 0 {
\t\terr = fmt.Errorf("benchmark found no healthy VPN nodes; current routing was retained")
\t\tfinish(err)
\t\treturn err
\t}

\t_ = h.Update("apply", 0, m.cfg.Pool.Size, "applying hot pool")''',
)
replace(
    "internal/core/manager.go",
    '''case state.DirectMode || state.ActiveNodeID == "" || mode == "startup" || mode == "manual" || mode == "emergency":''',
    '''case state.DirectMode || state.ActiveNodeID == "" || mode == "startup" || mode == "manual":''',
)
old_direct_case = '''\tcase winner < 0:
\t\tif err = m.xray.Direct(ctx); err != nil {
\t\t\tfinish(err)
\t\t\treturn err
\t\t}
\t\tdirect = true
\t\treason = "no healthy VPN nodes"
\tcase desired >= 0:'''
replace(
    "internal/core/manager.go",
    old_direct_case,
    '''\tcase desired >= 0:''',
)
replace(
    "internal/core/manager.go",
    '''\tdirect := false
\tfinalSlot := -1''',
    '''\tdirect := false
\tfinalSlot := -1''',
)
replace(
    "internal/core/manager.go",
    '''\t\t\ts.DirectMode = false
\t\t\ts.ActiveSlot = newSlots[finalSlot].Index''',
    '''\t\t\ts.DirectMode = false
\t\t\ts.PlatformBypass = false
\t\t\ts.HealthState = "healthy"
\t\t\ts.MonitoringDegraded = false
\t\t\ts.ActiveSlot = newSlots[finalSlot].Index''',
)

# Replace health/failover implementation with direct-path discrimination and platform bypass.
start = read("internal/core/manager.go").index("func (m *Manager) checkHealth(ctx context.Context) {")
end = read("internal/core/manager.go").index("func (m *Manager) queueBenchmark(mode string) {")
data = read("internal/core/manager.go")
new_block = r'''func (m *Manager) checkHealth(ctx context.Context) {
\tm.routeMu.Lock()
\tdefer m.routeMu.Unlock()
\tstate := m.store.State()
\tif !state.XrayConfigured {
\t\treturn
\t}
\tif !m.platform.XrayRunning(ctx) {
\t\t_ = m.enterDirect(ctx, "Xray unavailable")
\t\treturn
\t}
\tif err := m.reconcileSelection(ctx, state); err != nil {
\t\tm.log("error", "xray.selection_reconcile_failed", err.Error(), "", nil)
\t\t_ = m.enterDirect(ctx, "Xray API unavailable")
\t\treturn
\t}
\ttargets := m.cfg.TargetsByRole("health")
\tif state.DirectMode {
\t\tm.checkRecovery(ctx, state, targets)
\t\treturn
\t}
\tprober := bench.NewProber(m.cfg.Health.RequestTimeout.Duration, int64(m.cfg.Health.MaxResponseBytes))
\tproxy, _ := url.Parse(m.xray.HealthProxy())
\tvpnPassed, vpnTotal, vpnResults, directPassed, directTotal := comparePaths(ctx, prober, proxy, targets)
\tvpnHealthy := bench.Majority(vpnPassed, vpnTotal)
\tdirectHealthy := bench.Majority(directPassed, directTotal)
\tnow := time.Now().UTC()
\tif vpnHealthy {
\t\t_ = m.store.UpdateVolatile(func(s *model.State) error {
\t\t\ts.LastHealthAt = now
\t\t\ts.LastHealthMessage = fmt.Sprintf("%d/%d VPN health targets", vpnPassed, vpnTotal)
\t\t\ts.HealthState = "healthy"
\t\t\ts.MonitoringDegraded = false
\t\t\ts.ConsecutiveFailures = 0
\t\t\ts.ConsecutiveSuccess++
\t\t\treturn nil
\t\t})
\t\treturn
\t}
\tif !directHealthy {
\t\tmessage := "health targets unavailable through both VPN and direct paths"
\t\tif len(vpnResults) > 0 && vpnResults[0].Error != "" {
\t\t\tmessage = vpnResults[0].Error
\t\t}
\t\t_ = m.store.Update(func(s *model.State) error {
\t\t\ts.LastHealthAt = now
\t\t\ts.LastHealthMessage = message
\t\t\ts.HealthState = "monitoring_degraded"
\t\t\ts.MonitoringDegraded = true
\t\t\ts.ConsecutiveFailures = 0
\t\t\ts.ConsecutiveSuccess = 0
\t\t\treturn nil
\t\t})
\t\tm.log("warning", "health.inconclusive", message, "", nil)
\t\treturn
\t}
\tmessage := fmt.Sprintf("VPN path failed %d/%d; direct path passed %d/%d", vpnPassed, vpnTotal, directPassed, directTotal)
\t_ = m.store.Update(func(s *model.State) error {
\t\ts.LastHealthAt = now
\t\ts.LastHealthMessage = message
\t\ts.HealthState = "vpn_failed"
\t\ts.MonitoringDegraded = false
\t\ts.ConsecutiveFailures++
\t\ts.ConsecutiveSuccess = 0
\t\treturn nil
\t})
\tstate = m.store.State()
\tif state.ConsecutiveFailures >= m.cfg.Health.FailureThreshold {
\t\tm.emergencyFailover(ctx, state, targets)
\t}
}

func comparePaths(ctx context.Context, prober *bench.Prober, proxy *url.URL, targets []config.Target) (int, int, []bench.ProbeResult, int, int) {
\ttype result struct {
\t\tpassed int
\t\ttotal  int
\t\titems  []bench.ProbeResult
\t}
\tvpnCh := make(chan result, 1)
\tdirectCh := make(chan result, 1)
\tgo func() {
\t\tp, t, items := prober.CheckMajority(ctx, proxy, targets)
\t\tvpnCh <- result{p, t, items}
\t}()
\tgo func() {
\t\tp, t, items := prober.CheckMajority(ctx, nil, targets)
\t\tdirectCh <- result{p, t, items}
\t}()
\tvpn := <-vpnCh
\tdirect := <-directCh
\treturn vpn.passed, vpn.total, vpn.items, direct.passed, direct.total
}

func (m *Manager) emergencyFailover(ctx context.Context, state model.State, targets []config.Target) {
\tprober := bench.NewProber(minDuration(m.cfg.Health.RequestTimeout.Duration, 3*time.Second), int64(m.cfg.Health.MaxResponseBytes))
\torder := append([]model.Slot(nil), state.Pool...)
\tsort.SliceStable(order, func(i, j int) bool {
\t\tai, aj := order[i].LastVerifiedAt, order[j].LastVerifiedAt
\t\tif ai.Equal(aj) {
\t\t\treturn order[i].Score < order[j].Score
\t\t}
\t\treturn ai.After(aj)
\t})
\ttype candidate struct {
\t\tslot model.Slot
\t\tok   bool
\t}
\tresults := make(chan candidate, len(order))
\tprobeCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
\tdefer cancel()
\tcount := 0
\tfor _, slot := range order {
\t\tif slot.NodeID == "" || slot.Index == state.ActiveSlot {
\t\t\tcontinue
\t\t}
\t\tcount++
\t\tgo func(slot model.Slot) {
\t\t\tproxy, _ := url.Parse(m.xray.SlotProxy(slot.Index))
\t\t\tpassed, total, _ := prober.CheckMajority(probeCtx, proxy, targets)
\t\t\tresults <- candidate{slot: slot, ok: bench.Majority(passed, total)}
\t\t}(slot)
\t}
\tworking := map[int]model.Slot{}
\tfor i := 0; i < count; i++ {
\t\tresult := <-results
\t\tif result.ok {
\t\t\tworking[result.slot.Index] = result.slot
\t\t}
\t}
\tfor _, slot := range order {
\t\tif _, ok := working[slot.Index]; !ok {
\t\t\tcontinue
\t\t}
\t\tif err := m.xray.Switch(ctx, slot.Tag); err == nil {
\t\t\tnow := time.Now().UTC()
\t\t\t_ = m.store.Update(func(st *model.State) error {
\t\t\t\tst.ActiveSlot = slot.Index
\t\t\t\tst.ActiveNodeID = slot.NodeID
\t\t\t\tst.ActiveSince = now
\t\t\t\tst.DirectMode = false
\t\t\t\tst.PlatformBypass = false
\t\t\t\tst.HealthState = "healthy"
\t\t\t\tst.MonitoringDegraded = false
\t\t\t\tst.ConsecutiveFailures = 0
\t\t\t\tst.LastSwitchAt = now
\t\t\t\tst.LastSwitchReason = "emergency failover"
\t\t\t\treturn nil
\t\t\t})
\t\t\tm.log("warning", "failover.vpn", "switched to fallback VPN node", "", map[string]any{"node": slot.Label})
\t\t\tm.queueBenchmark("emergency")
\t\t\treturn
\t\t}
\t}
\t_ = m.enterDirect(ctx, "all VPN nodes unavailable")
}

func (m *Manager) enterDirect(ctx context.Context, reason string) error {
\tnow := time.Now().UTC()
\tif m.platform.XrayRunning(ctx) {
\t\tif err := m.xray.Direct(ctx); err == nil {
\t\t\t_ = m.store.Update(func(st *model.State) error {
\t\t\t\tst.DirectMode = true
\t\t\t\tst.PlatformBypass = false
\t\t\t\tst.HealthState = "direct"
\t\t\t\tst.ActiveSlot = -1
\t\t\t\tst.ActiveNodeID = ""
\t\t\t\tst.LastSwitchAt = now
\t\t\t\tst.LastSwitchReason = reason
\t\t\t\treturn nil
\t\t\t})
\t\t\tm.log("error", "failover.direct", reason+"; traffic is direct through Xray", "", nil)
\t\t\treturn nil
\t\t}
\t}
\tif err := m.platform.EnterDirectBypass(ctx); err != nil {
\t\t_ = m.store.Update(func(st *model.State) error {
\t\t\tst.XrayLastError = errors.Join(fmt.Errorf(reason), err).Error()
\t\t\tst.HealthState = "failed"
\t\t\treturn nil
\t\t})
\t\treturn err
\t}
\t_ = m.store.Update(func(st *model.State) error {
\t\tst.DirectMode = true
\t\tst.PlatformBypass = true
\t\tst.HealthState = "direct_bypass"
\t\tst.ActiveSlot = -1
\t\tst.ActiveNodeID = ""
\t\tst.LastSwitchAt = now
\t\tst.LastSwitchReason = reason
\t\treturn nil
\t})
\tm.log("error", "failover.platform_direct", reason+"; interception was bypassed", "", nil)
\treturn nil
}

func (m *Manager) checkRecovery(ctx context.Context, state model.State, targets []config.Target) {
\tif state.PlatformBypass {
\t\tif err := m.platform.LeaveDirectBypass(ctx); err != nil {
\t\t\treturn
\t\t}
\t\tif err := m.xray.WaitReady(ctx, 20*time.Second); err != nil {
\t\t\t_ = m.platform.EnterDirectBypass(context.Background())
\t\t\treturn
\t\t}
\t\t_ = m.xray.Direct(ctx)
\t\t_ = m.store.Update(func(st *model.State) error { st.PlatformBypass = false; return nil })
\t\tstate = m.store.State()
\t}
\tprober := bench.NewProber(m.cfg.Health.RequestTimeout.Duration, int64(m.cfg.Health.MaxResponseBytes))
\tcandidate := ""
\tindex := -1
\tfor _, slot := range state.Pool {
\t\tif slot.NodeID == "" {
\t\t\tcontinue
\t\t}
\t\tproxy, _ := url.Parse(m.xray.SlotProxy(slot.Index))
\t\tpassed, total, _ := prober.CheckMajority(ctx, proxy, targets)
\t\tif bench.Majority(passed, total) {
\t\t\tcandidate = slot.NodeID
\t\t\tindex = slot.Index
\t\t\tbreak
\t\t}
\t}
\tm.mu.Lock()
\tif candidate == "" {
\t\tm.recoveryNode = ""
\t\tm.recoveryCount = 0
\t\tm.mu.Unlock()
\t\treturn
\t}
\tif candidate == m.recoveryNode {
\t\tm.recoveryCount++
\t} else {
\t\tm.recoveryNode = candidate
\t\tm.recoveryCount = 1
\t}
\tcount := m.recoveryCount
\tm.mu.Unlock()
\tif count < m.cfg.Health.RecoveryThreshold {
\t\treturn
\t}
\tslot := state.Pool[index]
\tif err := m.xray.Switch(ctx, slot.Tag); err != nil {
\t\treturn
\t}
\tnow := time.Now().UTC()
\t_ = m.store.Update(func(st *model.State) error {
\t\tst.DirectMode = false
\t\tst.PlatformBypass = false
\t\tst.HealthState = "healthy"
\t\tst.MonitoringDegraded = false
\t\tst.ActiveSlot = index
\t\tst.ActiveNodeID = slot.NodeID
\t\tst.ActiveSince = now
\t\tst.LastSwitchAt = now
\t\tst.LastSwitchReason = "VPN recovered"
\t\tst.ConsecutiveFailures = 0
\t\tst.ConsecutiveSuccess = 0
\t\treturn nil
\t})
\tm.mu.Lock()
\tm.recoveryNode = ""
\tm.recoveryCount = 0
\tm.mu.Unlock()
\tm.log("info", "recovery.vpn", "VPN connectivity recovered", "", map[string]any{"node": slot.Label})
\tm.queueBenchmark("recovery")
}

func minDuration(a, b time.Duration) time.Duration {
\tif a <= 0 || a > b {
\t\treturn b
\t}
\treturn a
}

'''
new_block = new_block.replace("\\t", "\t")
write("internal/core/manager.go", data[:start] + new_block + data[end:])

# Manual route changes must leave any platform bypass first and persist a coherent state.
replace(
    "internal/core/manager.go",
    '''\t\tif err := m.xray.Switch(c, state.Pool[index].Tag); err != nil {''',
    '''\t\tif state.PlatformBypass {
\t\t\tif err := m.platform.LeaveDirectBypass(c); err != nil {
\t\t\t\treturn err
\t\t\t}
\t\t\tif err := m.xray.WaitReady(c, 20*time.Second); err != nil {
\t\t\t\treturn err
\t\t\t}
\t\t}
\t\tif err := m.xray.Switch(c, state.Pool[index].Tag); err != nil {''',
)
replace(
    "internal/core/manager.go",
    '''\t\t\ts.DirectMode = false
\t\t\ts.ActiveSlot = index''',
    '''\t\t\ts.DirectMode = false
\t\t\ts.PlatformBypass = false
\t\t\ts.HealthState = "healthy"
\t\t\ts.MonitoringDegraded = false
\t\t\ts.ActiveSlot = index''',
)
replace(
    "internal/core/manager.go",
    '''func (m *Manager) SwitchDirect(ctx context.Context) error {
\treturn m.RunAction(ctx, "switch-direct", "web", func(c context.Context) error {
\t\tm.routeMu.Lock()
\t\tdefer m.routeMu.Unlock()
\t\tif err := m.xray.Direct(c); err != nil {
\t\t\treturn err
\t\t}
\t\tnow := time.Now().UTC()
\t\treturn m.store.Update(func(s *model.State) error {
\t\t\ts.DirectMode = true
\t\t\ts.ActiveSlot = -1
\t\t\ts.ActiveNodeID = ""
\t\t\ts.LastSwitchAt = now
\t\t\ts.LastSwitchReason = "manual direct"
\t\t\treturn nil
\t\t})
\t})
}''',
    '''func (m *Manager) SwitchDirect(ctx context.Context) error {
\treturn m.RunAction(ctx, "switch-direct", "web", func(c context.Context) error {
\t\tm.routeMu.Lock()
\t\tdefer m.routeMu.Unlock()
\t\treturn m.enterDirect(c, "manual direct")
\t})
}''',
)

# Tests for direct path semantics and platform marker.
write("internal/platform/direct_bypass_test.go", r'''package platform

import (
    "context"
    "testing"

    "github.com/jarymor-ux/kee-route-manager/internal/config"
)

func TestGenericManagedDirectBypassMarker(t *testing.T) {
    cfg := config.Default()
    cfg.Paths.RunDir = t.TempDir()
    cfg.Platform.Kind = "linux-systemd"
    cfg.Platform.Linux.FirewallMode = "existing"
    g := newGeneric(cfg, Runner{}, "linux-systemd", false, false).(*generic)
    if err := g.EnterDirectBypass(context.Background()); err != ErrDirectBypassUnsupported {
        t.Fatalf("error = %v", err)
    }
}
''')

write("internal/bench/probe_parallel_test.go", r'''package bench

import (
    "context"
    "net/http"
    "net/http/httptest"
    "testing"
    "time"

    "github.com/jarymor-ux/kee-route-manager/internal/config"
)

func TestCheckMajorityRunsTargetsConcurrently(t *testing.T) {
    server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
        time.Sleep(100 * time.Millisecond)
        w.WriteHeader(http.StatusNoContent)
    }))
    defer server.Close()
    targets := []config.Target{
        {ID: "a", URL: server.URL, Policy: "2xx3xx"},
        {ID: "b", URL: server.URL, Policy: "2xx3xx"},
        {ID: "c", URL: server.URL, Policy: "2xx3xx"},
    }
    started := time.Now()
    passed, total, _ := NewProber(time.Second, 1024).CheckMajority(context.Background(), nil, targets)
    if passed != total || total != 3 {
        t.Fatalf("passed/total = %d/%d", passed, total)
    }
    if elapsed := time.Since(started); elapsed > 250*time.Millisecond {
        t.Fatalf("probes were not concurrent: %s", elapsed)
    }
}
''')
